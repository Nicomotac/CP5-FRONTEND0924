import { useEffect } from "react"

type ValorProps = {
    valor: number,
    aumentar: ()=>void
}

export default function ExemploEffect({valor,aumentar}:ValorProps){

    //É executado sempre que uma atualização acontece
    useEffect(()=>{
        console.log('Em todas as atualizações eu sou chamado!');        
    })

    //Só executa quando o componente é criado!
    useEffect(()=>{
        console.log('Sou chamado somente quando o componente é criado');        
    },[])

    //Só é executado quando as variáveis dentro do array sofrem alteração
    useEffect(()=>{
        console.log(`Sou chamado quando o valor muda. Valor= ${valor}`);
    },[valor])

    //Só é chamado quando o componente é desmontado da tela.
    useEffect(()=>{
        return ()=>{
            console.log('Ops, me apagaram.....');
        }
    },[])

    return(
        <div className="bg-white m-4 w-80 border-2 border-blue-900 p-4 text-center">
            <h2 className="text-blue-600 text-center font-bold text-3xl">Exemplo Effect</h2>
            <p className="font-bold m-2">Valor do State: {valor}</p>
            <button className="bg-emerald-600 cursor-pointer hover:bg-emerald-300 p-2 text-white font-bold rounded-md" onClick={aumentar}>Aumentar Valor</button>
        </div>
    )
}