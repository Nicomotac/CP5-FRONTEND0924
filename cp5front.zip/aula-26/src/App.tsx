import { useState } from "react"
import ExemploEffect from "./components/ExemploEffect"

export default function App(){

  const [valor, setValor] = useState<number>(0)
  const [comp, setComp] = useState<boolean>(true)

  
  function aumentar(){
    setValor(valor + 1)
  }
 

  return(
    <div className="min-h-screen bg-blue-200 flex flex-col justify-center items-center">
      <h1 className="text-5xl text-blue-800 font-bold">React - Hooks</h1>
      <button onClick={()=>setComp(!comp)} 
              className="bg-amber-600 p-4 rounded-md font-bold">
        {comp ? "Excluir Exemplo" : "Criar Exemplo"}
      </button>
      {comp ? <ExemploEffect valor={valor} aumentar={aumentar}/> : ""}
    </div>
  )
}